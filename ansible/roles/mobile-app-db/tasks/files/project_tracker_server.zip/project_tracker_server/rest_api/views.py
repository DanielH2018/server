from django.http import request
from rest_api.serializers import UserSerializer
from rest_framework import permissions, viewsets
from django.contrib.auth.models import User

import django_filters as filters

# Model Filters

class UserFilter(filters.FilterSet):

    class Meta:
        model = User
        fields = ['username']

# Model Viewsets

class UserViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = User.objects.all().order_by('id')
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_class = UserFilter

